/* Practice Assignment 1:

Complete this javascript file according to the individual instructions
given in the comments. 

*** DO NOT CHANGE any of the code that you are not instructed to. */

// 1) Define a variable named myNumber.

// 2) Assign a value of 5 to the variable myNumber.

// 3) Define a variable named myOtherNumber and assign it a value of 10

/* 4) Define a variable named myTotal and 
assign the product of myNumber and myOtherNumber to it  */

/* 5) Define a variable named myName and assign your name as the value. 
Define a 2nd variable named myCombo and assign it the result of the variables 
myName + myNumber  */

/* 6) Define a variable named myOtherCombo. Set the value of myOtherCombo equal to  
the variable myNumber + 8 */

// 7) Assign the remainder of myNumber divided by 5 to a variable named myRemainder

/* 8) Assign a value of 1 to a variable named i. 
On the next line, increment the value of i with a postfix operator */

/* 9) Assign a value of 5 to a variable named int. 
On the following line, decrement int using a prefix operator */

// 10) Assign an equality check of (myNumber === myName) to a variable named myBoolean
